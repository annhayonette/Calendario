<?php 

include 'eventos.php';

$dia = date('d', time());

if(isset($_POST['anio'])){ 
    $anio = $_POST['anio']; 
}else{ 
    $anio = date('Y', time());
}

$primer_dia = mktime(0,0,0,$mes, 1, $anio) ;

$nombre_mes = date("F", mktime(0, 0, 0, $mes, 1, $anio));

$dia_de_la_semana = date('D', $primer_dia); 

$dias_del_mes = cal_days_in_month(0, $mes, $anio);

$contador_dias = 1;

switch($nombre_mes){ 
    case "January": $nombre_mes = 'Enero'; break; 
    case "February": $nombre_mes = 'Febrero'; break; 
    case "March": $nombre_mes = 'Marzo'; break; 
    case "April": $nombre_mes = 'Abril'; break; 
    case "May": $nombre_mes = 'Mayo'; break; 
    case "June": $nombre_mes = 'Junio'; break; 
    case "July": $nombre_mes = 'Julio'; break; 
    case "August": $nombre_mes = 'Agosto'; break; 
    case "September": $nombre_mes = 'Septiembre'; break; 
    case "October": $nombre_mes = 'Octubre'; break; 
    case "November": $nombre_mes = 'Noviembre'; break; 
    case "December": $nombre_mes = 'Diciembre'; break; 
}

switch($dia_de_la_semana){ 
    case "Sun": $espacio_vacio = 0; break; 
    case "Mon": $espacio_vacio = 1; break; 
    case "Tue": $espacio_vacio = 2; break; 
    case "Wed": $espacio_vacio = 3; break; 
    case "Thu": $espacio_vacio = 4; break; 
    case "Fri": $espacio_vacio = 5; break; 
    case "Sat": $espacio_vacio = 6; break; 
 }

echo "<table id='calendario' border='0'>";
echo "<tr><th colspan=7> $nombre_mes $anio </th></tr>";
echo "<tr><td>Dom</td><td>Lun</td><td>Mar</td><td>Mie</td><td>Jue</td><td>Vie</td><td>Sab</td></tr>";
echo "<tr>";                 

 while ( $espacio_vacio > 0 ) { 
     echo "<td></td>"; 
     $espacio_vacio = $espacio_vacio-1; 
     $contador_dias++;
 } 

for($i=1; $i<=$dias_del_mes; $i++){

    if ($statement->rowCount() > 0) {
        echo "<td class='".$results[$i-1]->tipo_evento."' ><p style='display:none;'>".$results[$i-1]->descripcion."</p>".$i."</td>";
    }else{
        echo "<td>".$i."</td>";
    }
    
    $contador_dias++;
    
    if ($contador_dias > 7){
        echo "</tr><tr>";
        $contador_dias = 1;
    }
}

if ( $contador_dias >1 && $contador_dias <=7 ) { 
    echo "<td> </td>"; 
    $contador_dias++; 
} 

echo "</tr></table>"; 

    
    