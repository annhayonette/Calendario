<?php
try {
    if(isset($_POST['meses'])){ 
        $mes = $_POST['meses']; 
    }else{ 
        $mes = '1'; 
    }
    
    $mbd = new PDO('mysql:host=localhost;dbname=calendario;charset=utf8', 'root', '');
    
    $statement=$mbd->prepare("SELECT e.*, m.nombre FROM `eventos` AS e INNER JOIN `meses` AS m ON e.id_mes = m.id WHERE e.id_mes=".$mes);
    $statement->execute();
    $results=$statement->fetchAll(PDO::FETCH_OBJ);
    
    $mbd = null;

} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
