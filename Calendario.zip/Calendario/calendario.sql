-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-04-2017 a las 00:13:46
-- Versión del servidor: 5.6.24
-- Versión de PHP: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `calendario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos`
--

CREATE TABLE IF NOT EXISTS `eventos` (
  `id` int(11) NOT NULL,
  `numero_dia` int(11) NOT NULL,
  `id_mes` int(11) NOT NULL,
  `tipo_evento` varchar(100) NOT NULL,
  `descripcion` varchar(10000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `eventos`
--

INSERT INTO `eventos` (`id`, `numero_dia`, `id_mes`, `tipo_evento`, `descripcion`) VALUES
(2, 1, 1, 'evento historico', ' Entran en circulación las monedas y billetes de euro (año 2002)'),
(3, 2, 1, 'nacimiento', 'Nace en 1920 Isaac Asimov, escritor y bioquímico estadounidense (de origen ruso) popularmente recordado por las “tres leyes de la robótica” que la mayoría de los robots de sus novelas estaban diseñados para cumplir.'),
(4, 3, 1, 'nacimiento', 'Nace en 1892 J. R. R. Tolkien, escritor de “El hobbit” y “El señor de los anillos“; Alaska se convierte en el estado número 49 de los Estados Unidos en 1959.'),
(5, 4, 1, 'nacimiento', 'Nace en 1643 Isaac Newton [Las tres leyes de Newton]; Nace en 1809 Louis Braille, pedagogo francés con discapacidad visual conocido por diseñar el sistema de lecto-escritura para personas ciegas que lleva su nombre; se inaugura en 2010 el edificio más alto del mundo: el Burj Khalifa (828 m).'),
(6, 5, 1, 'evento historico', ' Nace en el año 1592 Sha Jahan, emperador del imperio Mongol de la India responsable de la construcción del Taj Mahal'),
(7, 6, 1, 'nacimiento', 'Nace en 1944 Rolf M. Zinkernagel, inmunólogo y premio nobel suizo conocido por descubrir el proceso mediante el cual las células del sistema inmunitario distinguen los microorganismos invasores de las propias células del organismo'),
(8, 7, 1, 'descubrimiento', ' Galileo descubre en 1610 varias estrellas pequeñas en la periferia de Júpiter que resultarían ser sus cuatro lunas principales, denominadas “lunas galileanas” en su honor.'),
(9, 8, 1, 'nacimiento', 'Nace en 1942 el físico teórico y divulgador científico Stephen Hawking; Mónaco se independiza de la República de Génova en el año 1297.'),
(10, 9, 1, 'nacimiento', 'Nace en 1868 Søren Sørensen, químico danés conocido por introducir el concepto de pH'),
(11, 10, 1, 'evento historico', 'Comienza a funcionar el metro en Londres en el año 1863.'),
(12, 11, 1, 'descubrimiento', 'William Herschel descubre las dos lunas más grandes de Urano: Titania y Oberón.'),
(13, 12, 1, 'nacimiento', 'Nace en 1628 Charles Perrault, escritor francés de cuentos clásicos infantiles como “Caperucita Roja“, “Cenicienta” o “El Gato con Botas“.'),
(14, 13, 1, 'nacimiento', 'Nace en el año 1927 el biólogo sudafricano Sydney Brenner, Premio Nobel de Fisiología o Medicina en el año 2002 “por sus investigaciones sobre la regulación del desarrollo de los órganos y la muerte celular programada”.'),
(15, 14, 1, 'evento historico', 'Matthias Zurbriggen alcanza en 1897, por primera vez en la historia, la cumbre del Aconcagua (la montaña más alta de América).'),
(16, 15, 1, 'nacimiento', 'Nace en 1929 Martin Luther King.'),
(17, 16, 1, 'nacimiento', 'Nace en 1932 Dian Fossey, primatóloga estadounidense conocida por haber dedicado su vida al estudio y protección de los gorilas de montaña (sería presuntamente asesinada a los 53 años por denunciar y combatir la actividad de los cazadores furtivos).'),
(18, 17, 1, 'nacimiento', 'Nace en 1706 Benjamin Franklin, político y científico estadounidense conocido por la invención del pararrayos.'),
(19, 18, 1, 'nacimiento', 'Nace en 1921 el físico estadounidense Yoichiro Nambu, Premio Nobel de Física en 2008 “por el descubrimiento del origen del problema de simetría rota, que predice la existencia de, al menos, tres familias de quarks en la naturaleza“.'),
(20, 19, 1, 'nacimiento', 'nace en 1809 el escritor y poeta estadounidense Edgard Allan Poe.'),
(21, 20, 1, 'nacimiento', 'Nace en 1930 Buzz Aldrin, astronauta estadounidense conocido por ser la segunda persona de la historia que puso un pie en la Luna.'),
(22, 21, 1, 'evento historico', 'Se bota en 1954 el “Nautilus” (SSN-571), el primer submarino de propulsión nuclear.'),
(23, 22, 1, 'nacimiento', 'nace en 1855 Albert Neisser, médico alemán conocido por descubrir el agente patógeno de la gonorrea.'),
(24, 23, 1, 'evento historico', 'En 1960 Jacques Piccard y Don Walsh descienden, por primera vez en la historia, al fondo del lugar más profundo del océano.'),
(25, 24, 1, 'nacimiento', 'Nace en 1941 el científico israelí Dan Shechtman, premio nobel de química en 2011 por el descubrimiento de los cuasicristales.'),
(26, 25, 1, 'nacimiento', 'Nace en 1627 Robert Boyle, físico y químico británico conocido por describir la relación entre la presión y el volumen de los gases a temperatura constante (ley de Boyle).'),
(27, 26, 1, 'descubrimiento', 'Se descubre en 1905 el diamante más grande del mundo.'),
(28, 27, 1, 'nacimiento', 'Nace en 1756 el músico austríaco Wolfgang Amadeus Mozart.'),
(29, 28, 1, 'evento historico', 'Se inicia en el año 1887 la construcción de la Torre Eiffel.'),
(30, 29, 1, 'nacimiento', 'Nace en 1773 Friedrich Mohs, geólogo alemán creador de la escala de Mohs (utilizada para medir la dureza de los minerales).'),
(31, 30, 1, 'celebracion', 'Se celebra, desde el año 1964, el Día Escolar de la No Violencia y la Paz (en conmemoración al día de fallecimiento de Mahatma Gandhi).'),
(32, 31, 1, 'descubrimiento', 'El explorador español Álvar Núñez Cabeza de Vaca descubre en el año 1542 las “cataratas del Iguazú” (una de las siete maravillas naturales del mundo).'),
(33, 1, 2, 'nacimiento', 'Nace en 1905 el físico italo-americano Emilio Gino Segré, premio nobel de física en el año 1959 por el descubrimiento del antiprotón.'),
(34, 2, 2, 'evento historico', 'El marinero escocés Alexander Selkirk es rescatado tras haber pasado más de cuatro años viviendo en una isla desierta (1709). Se cree que la historia de su supervivencia inspiró al escritor británico Daniel Defoe a escribir la novela “Robinson Crusoe“.'),
(35, 3, 2, 'evento historico', 'Grecia se independiza del Imperio otomano en 1830.'),
(36, 4, 2, 'celebracion', 'se celebra el Día Mundial contra el Cáncer.'),
(37, 5, 2, 'evento historico', 'En 1782 tropas españolas, con la ayuda de 4000 aliados franceses, recuperan la isla de Menorca después de más de 70 años de dominio británico.'),
(38, 6, 2, 'nacimiento', 'Nace en 1945 el músico jamaicano Bob Marley.'),
(39, 7, 2, 'nacimiento', 'Nace en 1812 Charles Dickens, escritor inglés conocido por obras como “Oliver Twist” o “Cuento de Navidad”.'),
(40, 8, 2, 'nacimiento', 'Nace en 1828 el escritor francés Julio Verne, principalmente conocido por novelas como: “La vuelta al mundo en ochenta días“, “Viaje al centro de la Tiera” y/o “Veinte mil leguas de viaje submarino“.'),
(41, 9, 2, 'nacimiento', 'Nace en 1954 Chris Gardner, filántropo y multimillonario estadounidense sobre el que está basado la película “En busca de la felicidad“.'),
(42, 10, 2, 'nacimiento', 'Nace en 1846 Ira Remsen, químico estadounidense coinventor de la sacarina.'),
(43, 11, 2, 'nacimiento', 'Nace en 1847 Thomas Edison, uno de los inventores más prolíficos de la historia (registró más de 1000 patentes).'),
(44, 12, 2, 'nacimiento', 'Nace en 1809 Charles Darwin.'),
(45, 13, 2, 'celebracion', 'Se celebra el Día Mundial de la Radio.'),
(46, 14, 2, 'nacimiento', 'Nace en 1859 el inventor de la primera noria de feria: George Ferris Jr; nace en 1819 Christopher Sholes, inventor del teclado QWERTY.'),
(47, 15, 2, 'nacimiento', 'Nace en 1642 Galileo Galilei, el padre de la ciencia y el precursor del método científico.'),
(48, 16, 2, 'evento historico', 'Entró en vigor en 2005 el Protocolo de Kioto para reducir las emisiones de los principales gases que causan el calentamiento global.'),
(49, 17, 2, 'nacimiento', 'Nació en 1963 Michael Jordan, considerado el “mejor jugador de baloncesto de la historia” y uno de los mayores saltadores de la NBA.'),
(50, 18, 2, 'descubrimiento', 'Clyde Tombaugh descubre Plutón en 1930 (fue el noveno y más pequeño planeta del Sistema Solar hasta el año 2006, en el que pasó a considerarse un planeta enano).'),
(51, 19, 2, 'nacimiento', 'Nace en 1473 Nicolás Copérnico, astrónomo polaco descubridor, entre otros hallazgos, de la «teoría heliocéntrica» (descubrió que la Tierra giraba alrededor del sol y no al revés, como se pensaba en aquella época).'),
(52, 20, 2, 'celebracion', 'Se celebra el Día Mundial de la Justicia Social.'),
(53, 21, 2, 'nacimiento', 'Nace en 1895 Henrik Dam, bioquímico y premio nobel danés conocido por el descubrimiento de la vitamina K (y su función en la coagulación de la sangre).'),
(54, 22, 2, 'nacimiento', 'Nace en 1857 Heinrich Rudolf Hertz, físico alemán descubridor del efecto fotoeléctrico y la propagación de las ondas electromagnéticas.'),
(55, 23, 2, 'evento historico', 'Se anuncia, en el año 1997, el nacimiento del primer mamífero clonado (la oveja Dolly).'),
(56, 24, 2, 'nacimiento', 'nace en 1955 Steve Jobs (fundador de Apple).'),
(57, 25, 2, 'evento historico', 'el inventor y empresario estadounidense Samuel Colt patenta el revólver en 1836.'),
(58, 26, 2, 'evento historico', 'En 1919, con objetivo de proteger la belleza natural del Gran Cañón del Colorado, se creó el “Parque Nacional del Gran Cañón“.'),
(59, 27, 2, 'descubrimiento', 'Los físicos Martin Kamen y Sam Ruben descubren en 1940 el carbono-14.'),
(60, 28, 2, 'nacimiento', 'Nace en 1901 el químico y doble premio nobel estadounidense Linus Pauling (recibió el Nobel de Química en 1954 por su descripción de la naturaleza de los enlaces químicos y el Nobel de la Paz en 1962 por sus esfuerzos por controlar la proliferación de armas nucleares). '),
(61, 29, 2, 'celebracion', 'Se celebra el Día Mundial de las Enfermedades Raras.'),
(62, 1, 3, 'nacimiento', 'Nace en 1810 Chopin (uno de los pianistas y compositores más importantes de la historia de la música).'),
(63, 2, 3, 'evento historico', 'Se lanza al espacio la “Pioneer 10” (1972). Esta sonda especial estadounidense, además de por su misión científica (estudio de Júpiter), será famosa por contener una placa para extraterrestres indicando la naturaleza y procedencia del ser humano.'),
(64, 3, 3, 'nacimiento', 'Nace en 1847 Alexander Graham Bell, inventor escocés conocido, entre otros hallazgos, por conseguir la patente del teléfono. (*) Se creía hasta hace no mucho que fue el inventor del dispositivo, si bien este hallazgo pertenece realmente al inventor italiano Antonio Meucci, que desarrolló el primer teléfono algunos años antes.'),
(65, 4, 3, 'nacimiento', 'Nace en 1678 el músico italiano Antonio Lucio Vivaldi.'),
(66, 5, 3, 'nacimiento', 'Winston Churchill, durante una conferencia en 1946 (EE. UU.), populariza el término “cortina de hierro” (también traducido como “telón de acero“).'),
(67, 6, 3, 'nacimiento', 'Nace en 1456 el escultor, pintor y arquitecto italiano Miguel Ángel Buonarotti (famoso por la escultura de “El David” y la obra pictórica que recubre la bóveda de la Capilla Sixtina).'),
(68, 7, 3, 'nacimiento', 'Nace en 1938 el físico francés Albert Fert, Premio Nobel de Física en el año 2007 por el co-descubrimiento de la magnetorresistencia gigante.'),
(69, 8, 3, 'celebracion', 'Se celebra el Día Internacional de la Mujer.'),
(70, 9, 3, 'nacimiento', 'Nace en 1934 Yuri Gagarin, astronauta soviético famoso por ser la primera persona que viajó al espacio exterior.'),
(71, 10, 3, 'nacimiento', 'Nace en 1833 el poeta español Pedro Antonio de Alarcón.'),
(72, 11, 3, 'celebracion', 'Se celebra, en recuerdo a las víctimas del mayor atentado terrorista de la historia de España y Europa, el “Día Europeo en Memoria de las Víctimas del Terrorismo“.'),
(73, 12, 3, 'evento historico', 'Se funda en 1913 la ciudad de Canberra (capital de Australia) [Países y capitales de Oceanía.'),
(74, 13, 3, 'descubrimiento', 'El astrónomo alemán William Herschel anuncia el descubrimiento del planeta Urano en 1781.'),
(75, 14, 3, 'nacimiento', 'Nace en 1879 el físico Albert Einstein, considerado el mejor científico del siglo XX.'),
(76, 15, 3, 'evento historico', 'Muere asesinado en el 44 a.C. el emperador romano Julio César.'),
(77, 16, 3, 'nacimiento', 'Nació en 1789 el físico y matemático alemán Georg Simon Ohm, descubridor de la Ley de Ohm.'),
(78, 17, 3, 'celebracion', 'Se celebra el Día de San Patricio.'),
(79, 18, 3, 'evento historico', 'el astronauta ruso Aleskséi Leónov realiza la primera caminata espacial de la historia en el año 1965 (estuvo fuera de la nave 12 minutos y 9 segundos).'),
(80, 19, 3, 'nacimiento', 'Nace en 1943 el ingeniero químico mexicano Mario Molina, premio nobel de química en el año 1995 por descubrir las causas de la desintegración de la capa de ozono.'),
(81, 20, 3, 'celebracion', 'Se celebra el Día Internacional de la Felicidad.'),
(82, 21, 3, 'evento historico', 'Se cierra la famosa prisión de Alcatraz.'),
(83, 22, 3, 'celebracion', 'Se celebra el Día Mundial del Agua con motivo de concienciar sobre su uso responsable.'),
(84, 23, 3, 'nacimiento', 'Nace en 1912 Wernher von Braun, ingeniero aeroespacial germano-estadounidense conocido por diseñar el cohete que llevó al hombre a la Luna.'),
(85, 24, 3, 'descubrimiento', 'El médico y Premio Nobel alemán Robert Koch anunció el descubrimiento de la bacteria responsable de la tuberculosis el 24 de marzo del año 1882.'),
(86, 25, 3, 'celebracion', 'Se celebra el “Día Internacional del Gofre“; nace en 1914 el genetista estadounidense Norman Borlaug, premio nobel de la paz en 1970 <<por aumentar la productividad agrícola en los países más necesitados>>.'),
(87, 26, 3, 'nacimiento', 'Nace en 1973 el cofundador de Google Larry Page.'),
(88, 27, 3, 'celebracion', 'Se celebra el Día Mundial del Teatro.'),
(89, 28, 3, 'evento historico', 'La ciudad de Bizancio (siglo VII a. C.), rebautizada como Constantinopla en el siglo IV, pasa a llamarse Estambul definitiva y oficialmente en 1930'),
(90, 29, 3, 'nacimiento', 'Nace en 1869 Aleš Hrdli?ka, antropólogo checo conocido por haber formulado la teoría que sostiene que todas las razas humanas tienen un origen común.'),
(91, 30, 3, 'nacimiento', 'Nace en 1853 el famoso pintor neerlandés Vincent van Gogh.'),
(92, 31, 3, 'nacimiento', 'Nace en 1596 el filósofo y matemático francés René Descartes, famoso por su planteamiento filosófico: «pienso, luego existo» (en latín: «cogito ergo sum»).');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `meses`
--

CREATE TABLE IF NOT EXISTS `meses` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `meses`
--

INSERT INTO `meses` (`id`, `nombre`) VALUES
(1, 'Enero'),
(2, 'Febrero'),
(3, 'Marzo'),
(4, 'Abril'),
(5, 'Mayo'),
(6, 'Junio'),
(7, 'Julio'),
(8, 'Agosto'),
(9, 'Septiembre'),
(10, 'Octubre'),
(11, 'Nobiembre'),
(12, 'Diciembre');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `meses`
--
ALTER TABLE `meses`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `eventos`
--
ALTER TABLE `eventos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=93;
--
-- AUTO_INCREMENT de la tabla `meses`
--
ALTER TABLE `meses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
