jQuery(document).ready(function( $ ) {
    
    $.ajax({
        url : '/calendario/crea calendario/calendar-maker.php',
        type: "GET",
        success:function(data)
        {
            $('#calendario').html(data);
        },
        error: function() 
        {
            $('#calendario').html('Imposible crear el calendario');      
        }
    });
        
});




