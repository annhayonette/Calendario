jQuery(document).ready(function( $ ) {
    
    $.ajax({
        url : 'http://localhost/entrevista/calendario/crea calendario/calendar-maker.php',
        type: "GET",
        success:function(data)
        {
            $('#calendario').html(data);
        },
        error: function() 
        {
            $('#calendario').html('Imposible crear el calendario');      
        }
    });
        
});




