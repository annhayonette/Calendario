jQuery(document).ready(function( $ ) {
    
    $("#meses").change(function(){
        
        $.ajax({
            url : '/calendario/crea calendario/calendar-maker.php',
            type: "POST",
            data : { meses : $('#meses').val(), anio : $('#anio').val() } ,
            success:function(response)
            {
                $('#calendario').html(response);
            },
            error: function() 
            {
                $('#calendario').html('No hay datos');      
            }
        });
        
        $.ajax(
        {
            url : '/calendario/crea calendario/eventos.php',
            type: "POST",
            data : { meses : $('#meses').val() } ,
            dataType: "json",
            success: function (response) { 
            },
            error: function() 
            {      
            }
        }); 
    }); 
    
    $("#anio").change(function(){
        
        $.ajax({
            url : '/calendario/crea calendario/calendar-maker.php',
            type: "POST",
            data : { meses : $('#meses').val(), anio : $('#anio').val() } ,
            success:function(response)
            {
                $('#calendario').html(response);
            },
            error: function() 
            {
                $('#calendario').html('No hay datos');      
            }
        });

    }); 
    
});

$(document).ready ( function () {
    $(document).on("mouseover", "#calendario tr > td", function () {
        $(this).find('p').show();
    });
    $(document).on("mouseleave", "#calendario tr > td", function () {
        $(this).find('p').hide();
    });
    
    $('#meses').val('1');
    $('#anio').val('2017');
});








